var playerUp = "X";
var gameOn = true;
var computerOpponent = true;
var victoryList = [
    ["c0r0", "c1r0", "c2r0"], // row 1
    ["c0r1", "c1r1", "c2r1"], // row 2
    ["c0r2", "c1r2", "c2r2"], // row 3
    ["c0r0", "c0r1", "c0r2"], // column 1
    ["c1r0", "c1r1", "c1r2"], // column 2
    ["c2r0", "c2r1", "c2r2"], // column 3
    ["c0r0", "c1r1", "c2r2"], // diagonal top left to bottom right
    ["c2r0", "c1r1", "c0r2"]  // diagonal top right to bottom left
];

function getEle(id) {
    return document.getElementById(id);
}

function makeMove(ele) {
    if (gameOn) {
        if (ele.innerHTML == "") {
            ele.innerHTML = playerUp;
            checkForWin();
            if (playerUp === "X") {
                playerUp = "O";
                if (computerOpponent && gameOn) {
                    makeMove(computerChoice());
                    playerUp = "X";
                }
            } else {
                playerUp = "X";
            }
        } else {
            alert("You can't make a move there.");
        }
    } else {
        alert("Game Over - you cannot make any more moves");
    }
}

function checkForWin() {
    var anyEmpty = false;

    for (var i = 0; i < 8; i++) {
        var victoryCheck = getEle(victoryList[i][0]).innerHTML + getEle(victoryList[i][1]).innerHTML + getEle(victoryList[i][2]).innerHTML;
        if (victoryCheck.length < 3)
            anyEmpty = true;
        if(victoryCheck === "XXX" || victoryCheck === "OOO") {
            gameOn = false;
            increaseScore();
            alert("Player " + playerUp + " is the winner!");
        }
    }

    if (anyEmpty === false && gameOn === true) {
        gameOn = false;
        alert("It's a tie");
    }
}

// Part 1
function resetGame() {
    for(var i = 0; i < 3; i++){
        for(var k = 0; k < 3; k++){
            document.getElementById("c" + i + "r" + k).innerHTML = "";
        }
    }
    gameOn = true;
    playerUp = "X";
}

// Part 2
function increaseScore() {

    if(playerUp === 'O') {
        document.getElementById('playerOScore').innerHTML = parseInt(document.getElementById('playerOScore').innerHTML) + 1;
    }
    if(playerUp === 'X') {
        document.getElementById('playerXScore').innerHTML = parseInt(document.getElementById('playerXScore').innerHTML) + 1;
    }

}

// Part 3
function computerChoice() {
    var ran1 = Math.floor((Math.random() * 3));
    var ran2 = Math.floor((Math.random() * 3));

    //Check for winning moves
    for(var i = 0; i < victoryList.length; i++){
        var winCheck = getEle(victoryList[i][0]).innerHTML + getEle(victoryList[i][1]).innerHTML + getEle(victoryList[i][2]).innerHTML;
        if(winCheck === 'OO'){
            for(var k = 0; k < 3; k++){
                var winCheck = getEle(victoryList[i][k]).innerHTML;
                if(getEle(victoryList[i][k]).innerHTML == "")
                    return getEle(victoryList[i][k]);
            }
        }
    }
    //Check for blocking moves
    for(var i = 0; i < victoryList.length; i++){
        var p1 = getEle(victoryList[i][0]).innerHTML;
        var p2 = getEle(victoryList[i][1]).innerHTML;
        var p3 = getEle(victoryList[i][2]).innerHTML;

        var winCheck = p1 + p2 + p3;

        if(winCheck === 'XX'){
            if(p1 === ""){
                return getEle(victoryList[i][0]);
            }
            else if(p2 === ""){
                return getEle(victoryList[i][1]);
            }
            else if(p3 === ""){
                return getEle(victoryList[i][2]);
            }
        }
    }
    //Choose random spot
    while(getEle('c' + ran1 + 'r' + ran2).innerHTML !== ""){
        ran1 = Math.floor((Math.random() * 3));
        ran2 = Math.floor((Math.random() * 3));
    }
    return getEle('c' + ran1 + 'r' + ran2);
}
