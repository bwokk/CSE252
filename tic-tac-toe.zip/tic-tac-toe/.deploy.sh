#!/bin/bash

if [ $# -eq 0 ]; then upload="*"; else upload="$1"; fi
uniqueid=`git remote -v show | head -1 | sed 's/\(.*\):\(.*\)\/\(.*\)/\2/g'`
sftp $uniqueid@cse252.spikeshroud.com <<EOF
cd public_html/tic-tac-toe
mput $upload
EOF
