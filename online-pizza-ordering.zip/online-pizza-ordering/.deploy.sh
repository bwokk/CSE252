#!/bin/bash

cd "${0%/*}"

if [ ! -f .uniqueid ]; then
    echo "This is a team project.  I need to know who you are to deploy correctly to your web space.  What is your Miami UniqueID? "
    read uniqueid
    echo "Thanks.  If you made a mistake entering your UniqueID, delete the .uniqueid file and run ./.deploy.sh again."
    echo $uniqueid | tr '[:upper:]' '[:lower:]' > .uniqueid
fi

uniqueid=$(<.uniqueid)

if [ $# -eq 0 ]; then upload="*" dirname="."; else upload=$(basename $1); dirname=$(dirname $1); fi

for x in `ls -d */ 2>/dev/null`; do
sftp $uniqueid@cse252.spikeshroud.com 2>/dev/null <<EOF
mkdir public_html/online-pizza-ordering/$x
EOF
done

sftp $uniqueid@cse252.spikeshroud.com <<EOF
cd public_html/online-pizza-ordering/$dirname
mput -r $dirname/$upload
EOF

